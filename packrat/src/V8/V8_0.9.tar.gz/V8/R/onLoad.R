.onLoad <- function(libname, pkgname){
  # Test for development
  # ct <- new_context()
  # ct$source(system.file("js/underscore.js", package = pkgname))
  # rm(ct)
}
