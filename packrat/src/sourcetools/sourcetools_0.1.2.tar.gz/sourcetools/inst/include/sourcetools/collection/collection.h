#ifndef SOURCE_TOOLS_COLLECTION_COLLECTION_H
#define SOURCE_TOOLS_COLLECTION_COLLECTION_H

#include <sourcetools/collection/Position.h>
#include <sourcetools/collection/Range.h>

#endif /* SOURCE_TOOLS_COLLECTION_COLLECTION_H */
