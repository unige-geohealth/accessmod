#ifndef SOURCE_TOOLS_COLLECTIONS_RANGE_H
#define SOURCE_TOOLS_COLLECTIONS_RANGE_H

namespace sourcetools {
namespace collections {

class Range
{
  // TODO: pair of positions
};
} // namespace collections
} // namespace sourcetools

#endif /* SOURCE_TOOLS_COLLECTIONS_RANGE_H */
