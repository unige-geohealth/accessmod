#ifndef SOURCE_TOOLS_CORE_CORE_H
#define SOURCE_TOOLS_CORE_CORE_H

#include <sourcetools/core/macros.h>
#include <sourcetools/core/util.h>

#endif /* SOURCE_TOOLS_CORE_CORE_H */
