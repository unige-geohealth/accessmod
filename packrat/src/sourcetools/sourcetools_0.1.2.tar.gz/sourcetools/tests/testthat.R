library(testthat)
library(sourcetools)

test_check("sourcetools")
