.SQLite.NA.string <- "\\N"  ## on input SQLite interprets \N as NULL (NA)
