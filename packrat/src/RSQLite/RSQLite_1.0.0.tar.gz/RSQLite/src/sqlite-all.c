#ifdef RSQLITE_USE_BUNDLED_SQLITE
#  include "sqlite/sqlite3.c"
#endif
