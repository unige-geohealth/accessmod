#ifndef __RSQLSITE_TYPES__
#define __RSQLSITE_TYPES__

#include "SqliteResult.h"
#include "SqliteConnection.h"

#endif // __RSQLSITE_TYPES__
