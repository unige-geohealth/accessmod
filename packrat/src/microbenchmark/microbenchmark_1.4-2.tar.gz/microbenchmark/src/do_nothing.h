#ifndef __DO_NOTHING_H__
#define __DO_NOTHING_H__

extern int do_nothing();
#endif
