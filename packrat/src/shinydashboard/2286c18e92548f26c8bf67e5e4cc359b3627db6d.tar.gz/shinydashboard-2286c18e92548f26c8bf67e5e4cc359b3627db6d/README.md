Shiny Dashboard
===============

[![Travis-CI Build Status](https://travis-ci.org/rstudio/shinydashboard.png?branch=master)](https://travis-ci.org/rstudio/shinydashboard)

## Installation

To install from CRAN:

```R
install.packages("shinydashboard")
```

See the documentation at http://rstudio.github.io/shinydashboard/
