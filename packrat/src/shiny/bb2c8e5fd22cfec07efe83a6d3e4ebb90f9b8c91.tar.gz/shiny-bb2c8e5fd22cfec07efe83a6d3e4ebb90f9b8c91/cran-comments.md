This submission is somewhat earlier than the suggested one month release cycle, because this version of Shiny fixes an important performance regression.
