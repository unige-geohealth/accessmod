
libxmlFeatures =
function()
{
  .Call("R_getXMLFeatures", PACKAGE = "XML")
}
