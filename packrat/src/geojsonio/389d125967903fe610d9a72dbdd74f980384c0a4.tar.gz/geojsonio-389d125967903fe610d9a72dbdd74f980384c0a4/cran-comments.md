R CMD CHECK passed on my local OS X install with R 3.2.1 and
R development version, Ubuntu running on Travis-CI, and Windows
R 3.2.1 and devel on Win-Builder.

This submission has a number of bug fixes, including importing all
non-base R functions (i.e., from methods, stats, and utils).

Thanks! Scott Chamberlain
