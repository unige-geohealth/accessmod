gdel <- function(x) {
  invisible(gistr::delete(x))  
}
