Shiny Dashboard
===============

[![Travis-CI Build Status](https://travis-ci.org/rstudio/shinydashboard.png?branch=master)](https://travis-ci.org/rstudio/shinydashboard)

NOTE: As of version 0.3.0, shinydashboard switched from [AdminLTE](https://github.com/almasaeed2010/AdminLTE) version 1 to version 2. The appearance is slightly different, but all existing code should continue to work.

## Installation

```R
devtools::install_github("rstudio/shinydashboard")
```

See the documentation at http://rstudio.github.io/shinydashboard/
